
package net.mcreator.nondystopiamod.potion;

import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffect;

public class PearlprotectionMobEffect extends MobEffect {
	public PearlprotectionMobEffect() {
		super(MobEffectCategory.BENEFICIAL, -13108);
	}

	@Override
	public boolean isDurationEffectTick(int duration, int amplifier) {
		return true;
	}
}
