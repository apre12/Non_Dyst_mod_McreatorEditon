
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.nondystopiamod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.nondystopiamod.block.UranusPortalBlock;
import net.mcreator.nondystopiamod.block.PipeBlock;
import net.mcreator.nondystopiamod.block.MicrowaveBlock;
import net.mcreator.nondystopiamod.block.IronpipeasblockBlock;
import net.mcreator.nondystopiamod.block.HeliumCloudBlock;
import net.mcreator.nondystopiamod.NonDystopiaModMod;

public class NonDystopiaModModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, NonDystopiaModMod.MODID);
	public static final RegistryObject<Block> URANUS_PORTAL = REGISTRY.register("uranus_portal", () -> new UranusPortalBlock());
	public static final RegistryObject<Block> HELIUM_CLOUD = REGISTRY.register("helium_cloud", () -> new HeliumCloudBlock());
	public static final RegistryObject<Block> PIPE = REGISTRY.register("pipe", () -> new PipeBlock());
	public static final RegistryObject<Block> IRONPIPEASBLOCK = REGISTRY.register("ironpipeasblock", () -> new IronpipeasblockBlock());
	public static final RegistryObject<Block> MICROWAVE = REGISTRY.register("microwave", () -> new MicrowaveBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
