
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.nondystopiamod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.nondystopiamod.NonDystopiaModMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class NonDystopiaModModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, NonDystopiaModMod.MODID);
	public static final RegistryObject<CreativeModeTab> NONDYSTPIA = REGISTRY.register("nondystpia",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.non_dystopia_mod.nondystpia")).icon(() -> new ItemStack(NonDystopiaModModItems.PRINTBUCKET.get())).displayItems((parameters, tabData) -> {
				tabData.accept(NonDystopiaModModItems.ONLY_ONE_USE_BLADE.get());
				tabData.accept(NonDystopiaModModItems.URANUS.get());
				tabData.accept(NonDystopiaModModBlocks.HELIUM_CLOUD.get().asItem());
				tabData.accept(NonDystopiaModModBlocks.PIPE.get().asItem());
				tabData.accept(NonDystopiaModModItems.FLOOPY.get());
				tabData.accept(NonDystopiaModModItems.WRITTEN_FLOOPY_C_HA_P.get());
				tabData.accept(NonDystopiaModModItems.IRONPIPE.get());
				tabData.accept(NonDystopiaModModBlocks.IRONPIPEASBLOCK.get().asItem());
				tabData.accept(NonDystopiaModModItems.WRITTEN_FLOOPY_SPEEKER.get());
				tabData.accept(NonDystopiaModModBlocks.MICROWAVE.get().asItem());
				tabData.accept(NonDystopiaModModItems.REDCOIL.get());
				tabData.accept(NonDystopiaModModItems.COPPERWIRE.get());
				tabData.accept(NonDystopiaModModItems.MAGICBOOK.get());
				tabData.accept(NonDystopiaModModItems.SIMPLEGUN.get());
				tabData.accept(NonDystopiaModModItems.BULLETITEM.get());
				tabData.accept(NonDystopiaModModItems.TONERCARTRIDGE.get());
				tabData.accept(NonDystopiaModModItems.PRINTBUCKET.get());
				tabData.accept(NonDystopiaModModItems.FREQUENCYMICROWAVE.get());
			})

					.build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.SPAWN_EGGS) {
			tabData.accept(NonDystopiaModModItems.PRINT_SPAWN_EGG.get());
			tabData.accept(NonDystopiaModModItems.URANUSSKYFISH_SPAWN_EGG.get());
			tabData.accept(NonDystopiaModModItems.GESTICK_SPAWN_EGG.get());
			tabData.accept(NonDystopiaModModItems.SPEEKER_SPAWN_EGG.get());
			tabData.accept(NonDystopiaModModItems.MEICROSPENCER_SPAWN_EGG.get());
		}
	}
}
