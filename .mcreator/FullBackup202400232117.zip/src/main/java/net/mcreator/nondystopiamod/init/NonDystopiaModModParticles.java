
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.nondystopiamod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.RegisterParticleProvidersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.mcreator.nondystopiamod.client.particle.PondParticle;
import net.mcreator.nondystopiamod.client.particle.PearlProtectionEffectParticle;
import net.mcreator.nondystopiamod.client.particle.MicrowaveshockparticleParticle;
import net.mcreator.nondystopiamod.client.particle.ElecdischargeParticle;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class NonDystopiaModModParticles {
	@SubscribeEvent
	public static void registerParticles(RegisterParticleProvidersEvent event) {
		event.registerSpriteSet(NonDystopiaModModParticleTypes.POND.get(), PondParticle::provider);
		event.registerSpriteSet(NonDystopiaModModParticleTypes.PEARL_PROTECTION_EFFECT.get(), PearlProtectionEffectParticle::provider);
		event.registerSpriteSet(NonDystopiaModModParticleTypes.MICROWAVESHOCKPARTICLE.get(), MicrowaveshockparticleParticle::provider);
		event.registerSpriteSet(NonDystopiaModModParticleTypes.ELECDISCHARGE.get(), ElecdischargeParticle::provider);
	}
}
