package net.mcreator.nondystopiamod.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.entity.living.LivingHurtEvent;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.SimpleParticleType;

import net.mcreator.nondystopiamod.init.NonDystopiaModModParticleTypes;
import net.mcreator.nondystopiamod.init.NonDystopiaModModMobEffects;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class PearldeployProcedure {
	@SubscribeEvent
	public static void onEntityAttacked(LivingHurtEvent event) {
		if (event != null && event.getEntity() != null) {
			execute(event, event.getEntity().level(), event.getEntity());
		}
	}

	public static void execute(LevelAccessor world, Entity entity) {
		execute(null, world, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (entity instanceof LivingEntity _livEnt0 && _livEnt0.hasEffect(NonDystopiaModModMobEffects.PEARLPROTECTION.get())) {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 20, 50, true, false));
			if (world instanceof ServerLevel _level)
				_level.sendParticles((SimpleParticleType) (NonDystopiaModModParticleTypes.PEARL_PROTECTION_EFFECT.get()), (entity.getX()), (entity.getY()), (entity.getZ()), 1, 0, 0, 0, 0.001);
		}
	}
}
