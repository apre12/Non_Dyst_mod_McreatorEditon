package net.mcreator.nondystopiamod.procedures;

import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.item.ItemStack;
import net.minecraft.util.RandomSource;
import net.minecraft.core.BlockPos;

import net.mcreator.nondystopiamod.init.NonDystopiaModModItems;
import net.mcreator.nondystopiamod.init.NonDystopiaModModBlocks;

public class CHaPProcedure {
	public static void execute(LevelAccessor world, double x, double y, double z) {
		world.setBlock(BlockPos.containing(x, y + 1, z), Blocks.AIR.defaultBlockState(), 3);
		world.setBlock(BlockPos.containing(x, y + 1, z), NonDystopiaModModBlocks.PIPE.get().defaultBlockState(), 3);
		world.setBlock(BlockPos.containing(x, y + 2, z), Blocks.AIR.defaultBlockState(), 3);
		world.setBlock(BlockPos.containing(x, y + 2, z), NonDystopiaModModBlocks.PIPE.get().defaultBlockState(), 3);
		world.setBlock(BlockPos.containing(x, y + 3, z), Blocks.AIR.defaultBlockState(), 3);
		world.setBlock(BlockPos.containing(x, y + 3, z), NonDystopiaModModBlocks.PIPE.get().defaultBlockState(), 3);
		world.setBlock(BlockPos.containing(x, y + 4, z), Blocks.AIR.defaultBlockState(), 3);
		world.setBlock(BlockPos.containing(x, y + 4, z), NonDystopiaModModBlocks.PIPE.get().defaultBlockState(), 3);
		world.setBlock(BlockPos.containing(x, y + 4, z), Blocks.AIR.defaultBlockState(), 3);
		world.setBlock(BlockPos.containing(x, y + 5, z), NonDystopiaModModBlocks.PIPE.get().defaultBlockState(), 3);
		world.setBlock(BlockPos.containing(x, y + 5, z), Blocks.AIR.defaultBlockState(), 3);
		{
			ItemStack _ist = new ItemStack(NonDystopiaModModItems.TONERCARTRIDGE.get());
			if (_ist.hurt(1, RandomSource.create(), null)) {
				_ist.shrink(1);
				_ist.setDamageValue(0);
			}
		}
	}
}
