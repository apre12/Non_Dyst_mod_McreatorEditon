
package net.mcreator.nondystopiamod.entity;

import net.minecraftforge.network.PlayMessages;
import net.minecraftforge.network.NetworkHooks;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.projectile.ItemSupplier;
import net.minecraft.world.entity.projectile.AbstractArrow;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.util.RandomSource;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.Packet;

import net.mcreator.nondystopiamod.procedures.MicrowavehitProcedure;
import net.mcreator.nondystopiamod.init.NonDystopiaModModItems;
import net.mcreator.nondystopiamod.init.NonDystopiaModModEntities;

@OnlyIn(value = Dist.CLIENT, _interface = ItemSupplier.class)
public class MicrowaveshootEntity extends AbstractArrow implements ItemSupplier {
	public static final ItemStack PROJECTILE_ITEM = new ItemStack(NonDystopiaModModItems.MICROWAVEFREQUENCYITEM.get());

	public MicrowaveshootEntity(PlayMessages.SpawnEntity packet, Level world) {
		super(NonDystopiaModModEntities.MICROWAVESHOOT.get(), world);
	}

	public MicrowaveshootEntity(EntityType<? extends MicrowaveshootEntity> type, Level world) {
		super(type, world);
	}

	public MicrowaveshootEntity(EntityType<? extends MicrowaveshootEntity> type, double x, double y, double z, Level world) {
		super(type, x, y, z, world);
	}

	public MicrowaveshootEntity(EntityType<? extends MicrowaveshootEntity> type, LivingEntity entity, Level world) {
		super(type, entity, world);
	}

	@Override
	public Packet<ClientGamePacketListener> getAddEntityPacket() {
		return NetworkHooks.getEntitySpawningPacket(this);
	}

	@Override
	@OnlyIn(Dist.CLIENT)
	public ItemStack getItem() {
		return PROJECTILE_ITEM;
	}

	@Override
	protected ItemStack getPickupItem() {
		return PROJECTILE_ITEM;
	}

	@Override
	protected void doPostHurtEffects(LivingEntity entity) {
		super.doPostHurtEffects(entity);
		entity.setArrowCount(entity.getArrowCount() - 1);
	}

	@Override
	public void onHitEntity(EntityHitResult entityHitResult) {
		super.onHitEntity(entityHitResult);
		MicrowavehitProcedure.execute(this.level(), entityHitResult.getEntity());
	}

	@Override
	public void tick() {
		super.tick();
		if (this.inGround)
			this.discard();
	}

	public static MicrowaveshootEntity shoot(Level world, LivingEntity entity, RandomSource source) {
		return shoot(world, entity, source, 1f, 1, 0);
	}

	public static MicrowaveshootEntity shoot(Level world, LivingEntity entity, RandomSource source, float pullingPower) {
		return shoot(world, entity, source, pullingPower * 1f, 1, 0);
	}

	public static MicrowaveshootEntity shoot(Level world, LivingEntity entity, RandomSource random, float power, double damage, int knockback) {
		MicrowaveshootEntity entityarrow = new MicrowaveshootEntity(NonDystopiaModModEntities.MICROWAVESHOOT.get(), entity, world);
		entityarrow.shoot(entity.getViewVector(1).x, entity.getViewVector(1).y, entity.getViewVector(1).z, power * 2, 0);
		entityarrow.setSilent(true);
		entityarrow.setCritArrow(false);
		entityarrow.setBaseDamage(damage);
		entityarrow.setKnockback(knockback);
		entityarrow.setSecondsOnFire(100);
		world.addFreshEntity(entityarrow);
		return entityarrow;
	}

	public static MicrowaveshootEntity shoot(LivingEntity entity, LivingEntity target) {
		MicrowaveshootEntity entityarrow = new MicrowaveshootEntity(NonDystopiaModModEntities.MICROWAVESHOOT.get(), entity, entity.level());
		double dx = target.getX() - entity.getX();
		double dy = target.getY() + target.getEyeHeight() - 1.1;
		double dz = target.getZ() - entity.getZ();
		entityarrow.shoot(dx, dy - entityarrow.getY() + Math.hypot(dx, dz) * 0.2F, dz, 1f * 2, 12.0F);
		entityarrow.setSilent(true);
		entityarrow.setBaseDamage(1);
		entityarrow.setKnockback(0);
		entityarrow.setCritArrow(false);
		entityarrow.setSecondsOnFire(100);
		entity.level().addFreshEntity(entityarrow);
		return entityarrow;
	}
}
