
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.nondystopiamod.init;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.client.renderer.entity.ThrownItemRenderer;

import net.mcreator.nondystopiamod.client.renderer.UranusskyfishRenderer;
import net.mcreator.nondystopiamod.client.renderer.ThrowedpipeRenderer;
import net.mcreator.nondystopiamod.client.renderer.SpeekerRenderer;
import net.mcreator.nondystopiamod.client.renderer.PrintRenderer;
import net.mcreator.nondystopiamod.client.renderer.MeicrospencerRenderer;
import net.mcreator.nondystopiamod.client.renderer.GestickRenderer;
import net.mcreator.nondystopiamod.client.renderer.BulletRenderer;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class NonDystopiaModModEntityRenderers {
	@SubscribeEvent
	public static void registerEntityRenderers(EntityRenderersEvent.RegisterRenderers event) {
		event.registerEntityRenderer(NonDystopiaModModEntities.PRINT.get(), PrintRenderer::new);
		event.registerEntityRenderer(NonDystopiaModModEntities.PRINT_PROJECTILE.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(NonDystopiaModModEntities.URANUSSKYFISH.get(), UranusskyfishRenderer::new);
		event.registerEntityRenderer(NonDystopiaModModEntities.GESTICK.get(), GestickRenderer::new);
		event.registerEntityRenderer(NonDystopiaModModEntities.SPEEKER.get(), SpeekerRenderer::new);
		event.registerEntityRenderer(NonDystopiaModModEntities.MEICROSPENCER.get(), MeicrospencerRenderer::new);
		event.registerEntityRenderer(NonDystopiaModModEntities.MAGIC.get(), ThrownItemRenderer::new);
		event.registerEntityRenderer(NonDystopiaModModEntities.THROWEDPIPE.get(), ThrowedpipeRenderer::new);
		event.registerEntityRenderer(NonDystopiaModModEntities.BULLET.get(), BulletRenderer::new);
		event.registerEntityRenderer(NonDystopiaModModEntities.MICROWAVESHOOT.get(), ThrownItemRenderer::new);
	}
}
