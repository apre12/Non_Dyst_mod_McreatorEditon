
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.nondystopiamod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.common.ForgeSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.nondystopiamod.item.WrittenFloopySpeekerItem;
import net.mcreator.nondystopiamod.item.WrittenFloopyCHaPItem;
import net.mcreator.nondystopiamod.item.UranusItem;
import net.mcreator.nondystopiamod.item.TonercartridgeItem;
import net.mcreator.nondystopiamod.item.SimplegunItem;
import net.mcreator.nondystopiamod.item.RedcoilItem;
import net.mcreator.nondystopiamod.item.PrintbucketItem;
import net.mcreator.nondystopiamod.item.OnlyOneUseBladeItem;
import net.mcreator.nondystopiamod.item.MicrowavefrequencyitemItem;
import net.mcreator.nondystopiamod.item.MagicbookItem;
import net.mcreator.nondystopiamod.item.IronpipeItem;
import net.mcreator.nondystopiamod.item.FrequencymicrowaveItem;
import net.mcreator.nondystopiamod.item.FloopyItem;
import net.mcreator.nondystopiamod.item.CopperwireItem;
import net.mcreator.nondystopiamod.item.BulletitemItem;
import net.mcreator.nondystopiamod.NonDystopiaModMod;

public class NonDystopiaModModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, NonDystopiaModMod.MODID);
	public static final RegistryObject<Item> ONLY_ONE_USE_BLADE = REGISTRY.register("only_one_use_blade", () -> new OnlyOneUseBladeItem());
	public static final RegistryObject<Item> URANUS = REGISTRY.register("uranus", () -> new UranusItem());
	public static final RegistryObject<Item> HELIUM_CLOUD = block(NonDystopiaModModBlocks.HELIUM_CLOUD);
	public static final RegistryObject<Item> PIPE = block(NonDystopiaModModBlocks.PIPE);
	public static final RegistryObject<Item> FLOOPY = REGISTRY.register("floopy", () -> new FloopyItem());
	public static final RegistryObject<Item> WRITTEN_FLOOPY_C_HA_P = REGISTRY.register("written_floopy_c_ha_p", () -> new WrittenFloopyCHaPItem());
	public static final RegistryObject<Item> IRONPIPE = REGISTRY.register("ironpipe", () -> new IronpipeItem());
	public static final RegistryObject<Item> PRINT_SPAWN_EGG = REGISTRY.register("print_spawn_egg", () -> new ForgeSpawnEggItem(NonDystopiaModModEntities.PRINT, -13421773, -3355444, new Item.Properties()));
	public static final RegistryObject<Item> IRONPIPEASBLOCK = block(NonDystopiaModModBlocks.IRONPIPEASBLOCK);
	public static final RegistryObject<Item> URANUSSKYFISH_SPAWN_EGG = REGISTRY.register("uranusskyfish_spawn_egg", () -> new ForgeSpawnEggItem(NonDystopiaModModEntities.URANUSSKYFISH, -3342388, -16724788, new Item.Properties()));
	public static final RegistryObject<Item> GESTICK_SPAWN_EGG = REGISTRY.register("gestick_spawn_egg", () -> new ForgeSpawnEggItem(NonDystopiaModModEntities.GESTICK, -13369498, -6710887, new Item.Properties()));
	public static final RegistryObject<Item> WRITTEN_FLOOPY_SPEEKER = REGISTRY.register("written_floopy_speeker", () -> new WrittenFloopySpeekerItem());
	public static final RegistryObject<Item> SPEEKER_SPAWN_EGG = REGISTRY.register("speeker_spawn_egg", () -> new ForgeSpawnEggItem(NonDystopiaModModEntities.SPEEKER, -1, -16777216, new Item.Properties()));
	public static final RegistryObject<Item> MICROWAVE = block(NonDystopiaModModBlocks.MICROWAVE);
	public static final RegistryObject<Item> REDCOIL = REGISTRY.register("redcoil", () -> new RedcoilItem());
	public static final RegistryObject<Item> COPPERWIRE = REGISTRY.register("copperwire", () -> new CopperwireItem());
	public static final RegistryObject<Item> MEICROSPENCER_SPAWN_EGG = REGISTRY.register("meicrospencer_spawn_egg", () -> new ForgeSpawnEggItem(NonDystopiaModModEntities.MEICROSPENCER, -52, -10066330, new Item.Properties()));
	public static final RegistryObject<Item> MAGICBOOK = REGISTRY.register("magicbook", () -> new MagicbookItem());
	public static final RegistryObject<Item> SIMPLEGUN = REGISTRY.register("simplegun", () -> new SimplegunItem());
	public static final RegistryObject<Item> BULLETITEM = REGISTRY.register("bulletitem", () -> new BulletitemItem());
	public static final RegistryObject<Item> TONERCARTRIDGE = REGISTRY.register("tonercartridge", () -> new TonercartridgeItem());
	public static final RegistryObject<Item> PRINTBUCKET = REGISTRY.register("printbucket", () -> new PrintbucketItem());
	public static final RegistryObject<Item> FREQUENCYMICROWAVE = REGISTRY.register("frequencymicrowave", () -> new FrequencymicrowaveItem());
	public static final RegistryObject<Item> MICROWAVEFREQUENCYITEM = REGISTRY.register("microwavefrequencyitem", () -> new MicrowavefrequencyitemItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
