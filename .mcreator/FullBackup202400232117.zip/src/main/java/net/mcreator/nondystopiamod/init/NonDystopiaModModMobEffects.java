
/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.nondystopiamod.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.effect.MobEffect;

import net.mcreator.nondystopiamod.potion.PearlprotectionMobEffect;
import net.mcreator.nondystopiamod.potion.MicrowavedamageMobEffect;
import net.mcreator.nondystopiamod.potion.LivetimerMobEffect;
import net.mcreator.nondystopiamod.potion.ElectrostaticchargeMobEffect;
import net.mcreator.nondystopiamod.NonDystopiaModMod;

public class NonDystopiaModModMobEffects {
	public static final DeferredRegister<MobEffect> REGISTRY = DeferredRegister.create(ForgeRegistries.MOB_EFFECTS, NonDystopiaModMod.MODID);
	public static final RegistryObject<MobEffect> PEARLPROTECTION = REGISTRY.register("pearlprotection", () -> new PearlprotectionMobEffect());
	public static final RegistryObject<MobEffect> LIVETIMER = REGISTRY.register("livetimer", () -> new LivetimerMobEffect());
	public static final RegistryObject<MobEffect> MICROWAVEDAMAGE = REGISTRY.register("microwavedamage", () -> new MicrowavedamageMobEffect());
	public static final RegistryObject<MobEffect> ELECTROSTATICCHARGE = REGISTRY.register("electrostaticcharge", () -> new ElectrostaticchargeMobEffect());
}
