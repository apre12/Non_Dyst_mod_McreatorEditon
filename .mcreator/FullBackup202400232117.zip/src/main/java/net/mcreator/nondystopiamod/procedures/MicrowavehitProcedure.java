package net.mcreator.nondystopiamod.procedures;

import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.resources.ResourceKey;
import net.minecraft.core.registries.Registries;
import net.minecraft.core.particles.SimpleParticleType;
import net.minecraft.core.BlockPos;

import net.mcreator.nondystopiamod.init.NonDystopiaModModParticleTypes;
import net.mcreator.nondystopiamod.init.NonDystopiaModModMobEffects;

public class MicrowavehitProcedure {
	public static void execute(LevelAccessor world, Entity entity) {
		if (entity == null)
			return;
		if (world instanceof ServerLevel _level)
			_level.sendParticles((SimpleParticleType) (NonDystopiaModModParticleTypes.MICROWAVESHOCKPARTICLE.get()), (entity.getX()), (entity.getY()), (entity.getZ()), 50, 1, 1, 1, 0.5);
		if (entity instanceof LivingEntity _livEnt4 && _livEnt4.hasEffect(NonDystopiaModModMobEffects.ELECTROSTATICCHARGE.get())) {
			if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(NonDystopiaModModMobEffects.ELECTROSTATICCHARGE.get()) ? _livEnt.getEffect(NonDystopiaModModMobEffects.ELECTROSTATICCHARGE.get()).getAmplifier() : 0) <= 50) {
				if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
					_entity.addEffect(new MobEffectInstance(NonDystopiaModModMobEffects.ELECTROSTATICCHARGE.get(), 120,
							(int) ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(NonDystopiaModModMobEffects.ELECTROSTATICCHARGE.get()) ? _livEnt.getEffect(NonDystopiaModModMobEffects.ELECTROSTATICCHARGE.get()).getAmplifier() : 0)
									+ 1)));
			} else {
				entity.setSprinting(false);
				if (world instanceof ServerLevel _level) {
					Entity entityToSpawn = EntityType.LIGHTNING_BOLT.spawn(_level, BlockPos.containing(entity.getX(), entity.getY(), entity.getZ()), MobSpawnType.MOB_SUMMONED);
					if (entityToSpawn != null) {
						entityToSpawn.setYRot(world.getRandom().nextFloat() * 360F);
					}
				}
				if (world instanceof ServerLevel _level)
					_level.sendParticles((SimpleParticleType) (NonDystopiaModModParticleTypes.ELECDISCHARGE.get()), (entity.getX()), (entity.getY()), (entity.getZ()), 50, 1, 1, 1, 0.5);
			}
		} else {
			if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
				_entity.addEffect(new MobEffectInstance(NonDystopiaModModMobEffects.ELECTROSTATICCHARGE.get(), 120, 1));
		}
		if (entity instanceof LivingEntity _entity && !_entity.level().isClientSide())
			_entity.addEffect(new MobEffectInstance(NonDystopiaModModMobEffects.MICROWAVEDAMAGE.get(), 1, 1));
		entity.hurt(new DamageSource(world.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(ResourceKey.create(Registries.DAMAGE_TYPE, new ResourceLocation("non_dystopia_mod:microwavedamagetype")))),
				(float) ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) * ((entity instanceof LivingEntity _livEnt ? _livEnt.getMaxHealth() : -1) / 100)));
	}
}
