package net.mcreator.nondystopiamod.procedures;

import net.minecraft.world.item.ItemStack;
import net.minecraft.util.RandomSource;

import net.mcreator.nondystopiamod.init.NonDystopiaModModItems;

public class MinuscartridgeProcedure {
	public static void execute() {
		{
			ItemStack _ist = new ItemStack(NonDystopiaModModItems.TONERCARTRIDGE.get());
			if (_ist.hurt((int) 0.001, RandomSource.create(), null)) {
				_ist.shrink(1);
				_ist.setDamageValue(0);
			}
		}
	}
}
